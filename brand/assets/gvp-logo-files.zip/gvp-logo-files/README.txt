Grand Vision Perspective logo files (SVG)

horizontal-lockup  Default. Websites, email signatures, document headers.
vertical-lockup    Mark above wordmark. Covers and square formats.
vantage            Mark only, for small spaces and profile images.
wordmark           Name only, where the mark would be redundant.

Each comes in coloured (gold), black (single-colour print) and white (dark backgrounds).
Please do not recolour, stretch or redraw the files.
Questions: connect@grandvisionperspective.com
